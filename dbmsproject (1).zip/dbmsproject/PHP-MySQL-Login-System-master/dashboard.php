<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Login - SB Admin</title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                
                <main>
                    <div class="container-fluid px-4">
                        <span>USERS &nbsp;&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</span>
                       
                        
                            
							<?php
									   
					  $con=mysqli_connect('localhost','root','','loginSystem');
					  $sql="SELECT * FROM `registration`";
					  $rs=mysqli_query($con,$sql);
					  
					  ?>
                            <div class="card-body">
                                <table border="1" cellspacing="10" cellpadding="10">
								
                                    <thead>
									
                                        <tr>
                                        <th>SR.No</th>
										<th>First Name</th>
                                        <th>Last Name</th>
										<th>E-Mail Id</th> 
                                        <th>Update</th>
                                        <th>Delete</th>
                                        
                                        </tr>
                                    </thead>
									<tbody>
                                   <?php
								   $count=1;
								   while($rw=mysqli_fetch_row($rs))
					  {
					  ?>    
                        <tr>
                          <td><?php echo $count;?></td>
                          <td><?php echo $rw[0];?></td>
                          <td><?php echo $rw[1];?></td>
                          <td><?php echo $rw[2];?></td>
                          <td><a class="btn btn-primary btn-block" name="btn" href="update.php">Update</a></td>
                          <td><a class="btn btn-primary btn-block" name="btn" href="delete.php">Delete</a></td>
						   </tr>
                       <?php
                       $count++;
					   }
					   ?>
								
								   
                                
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2022</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>
 
    